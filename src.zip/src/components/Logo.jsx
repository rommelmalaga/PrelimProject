import React from 'react';


const Logo = () => {
    return(
        <div className='logo'>        
            <h4 className=''>Instagram</h4>
        </div>
    );
};

export default Logo;