import React from 'react';


const Footer = () => {
    return(
        <div className=''>        
            <p>Instagram</p>
        </div>
    );
};

export default Footer;